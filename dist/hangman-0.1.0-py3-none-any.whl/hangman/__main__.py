from hangman.game import hangman

if __name__ == '__main__':
    hangman()
